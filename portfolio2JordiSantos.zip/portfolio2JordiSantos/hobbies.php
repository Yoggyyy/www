<?php
/**
 * Archivo hobbies que contiene los hobbies.
 *
 * @author Jordi Santos Torres
 * @version 1.0.0
 */
?>
<?php
  require_once($_SERVER['DOCUMENT_ROOT'] . '/includes/head.inc.php');
?>
<!DOCTYPE html>
<html lang="en">
 
<body>
<?php
  require_once($_SERVER['DOCUMENT_ROOT'] . '/includes/header.inc.php');
?>
  <section class="hobbies">
    <h2>Hobbies</h2>
    <p>Me apasiona el mundo de los videojuegos, donde disfruto explorando nuevas historias y retos. También soy un gran aficionado al anime. Me encanta leer, ya sea libros o mangas. El deporte me gusta mucho,
      ya que me mantiene activo y enfocado. Además, me encantan los perros, quienes me aportan compañía, alegría y mucho cariño en mi día a día, tengo 2.</p>
  </section>
  <?php
    require_once($_SERVER['DOCUMENT_ROOT'] . '/includes/footer.inc.php');
    ?>
</body>

</html>