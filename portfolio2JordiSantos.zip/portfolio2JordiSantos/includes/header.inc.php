<header>
        <h1>Portfolio Jordi Santos Torres</h1>
        <nav>
            <ul>
                <li><a href="/index.php">Presentación</a></li>
                <li><a href="/skills.php">Skills</a></li>
                <li><a href="/experienciaLaboral.php">Experiencia Laboral</a></li>
                <li><a href="/hobbies.php">Hobbies</a></li>
            </ul>
        </nav>
    </header>