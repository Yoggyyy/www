<footer class="footer">
        <div class="wrap-footer">
          <div class="rrss">
            <h5>Redes Sociales</h5>
            <ul>
                <li><a href="https://www.facebook.com">
                        <img src="/imagenes/face.png" alt="Facebook">
                    </a></li>
                <li><a href="https://www.instagram.com">
                        <img src="/imagenes/insta.png" alt="Instagram">
                    </a></li>
                <li><a href="https://twitter.com">
                        <img src="/imagenes/x.png" alt="X">
                    </a></li>
            </ul>
        </div>
        </div>
        <div class="footer-creds">
          <div class="copy-creds">
            <p>©2022 · Todos los derechos reservados.</p>
          </div>
          <div class="legal-creds">
            <ul>
              <li><a href="">Política de Privacidad</a></li>
              <li><a href="">Plítica de Cookies</a></li>
              <li><a href="">Aviso Legal</a></li>
            </ul>
          </div>
        </div>
      </footer>