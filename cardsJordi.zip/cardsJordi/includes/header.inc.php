<?php
/**
 * Archivo que contiene el inc de header
 *
 * @author Jordi Santos Torres
 * @version 1.0.0
 */
?>
<header>
    <nav>
        <ul>
            <li><a href="/index.php">BlackAce</a></li>
            <li><a href="/higherJordiSantos.php">Modalidad: Carta mas alta</a></li>
            <li><a href="/blackjackJordiSantos.php">Modalidad: BlackJack</a></li>
        </ul>
    </nav>
</header>


